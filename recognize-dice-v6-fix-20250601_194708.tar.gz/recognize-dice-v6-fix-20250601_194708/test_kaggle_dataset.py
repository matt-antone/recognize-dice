#!/usr/bin/env python3
"""
Test our dice detection system against the nell-byler Kaggle dataset.
This will help us understand performance on real-world data and validate our angle hypothesis.
"""

import sys
import os
import cv2
import numpy as np
import json
import time
from datetime import datetime
from pathlib import Path

# Add src directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

try:
    from src.detection.fallback_detection import FallbackDetection
    from src.utils.config import Config
    from src.utils.logger import setup_logger
except ImportError as e:
    print(f"Import error: {e}")
    print("Please ensure you're running from the project root directory")
    sys.exit(1)


class KaggleDatasetTester:
    """Test our detection system against the nell-byler Kaggle dataset."""
    
    def __init__(self):
        self.config = Config()
        self.logger = setup_logger(__name__)
        self.detector = None
        self.dataset_path = Path("kaggle_dataset")
        self.results = []
        
    def setup_kaggle_api(self):
        """Set up Kaggle API (requires user to have configured credentials)."""
        print("Setting up Kaggle API...")
        print("NOTE: You need to:")
        print("1. Go to kaggle.com -> Account -> Create API Token")
        print("2. Place kaggle.json in ~/.kaggle/ directory")
        print("3. chmod 600 ~/.kaggle/kaggle.json")
        
        try:
            import kaggle
            return True
        except Exception as e:
            print(f"Kaggle API setup failed: {e}")
            print("Please follow the setup instructions above")
            return False
    
    def download_dataset(self):
        """Download the nell-byler d6 dice dataset."""
        if self.dataset_path.exists():
            print("Dataset already exists locally")
            return True
            
        if not self.setup_kaggle_api():
            return False
            
        try:
            print("Downloading nell-byler d6 dice dataset...")
            os.system(f"kaggle datasets download -d nellbyler/d6-dice -p {self.dataset_path}")
            
            # Extract if it's a zip file
            zip_files = list(self.dataset_path.glob("*.zip"))
            if zip_files:
                import zipfile
                with zipfile.ZipFile(zip_files[0], 'r') as zip_ref:
                    zip_ref.extractall(self.dataset_path)
                zip_files[0].unlink()  # Remove zip file
                
            print(f"✅ Dataset downloaded to {self.dataset_path}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to download dataset: {e}")
            return False
    
    def analyze_dataset_structure(self):
        """Analyze the downloaded dataset structure."""
        print("\n=== DATASET ANALYSIS ===")
        
        if not self.dataset_path.exists():
            print("❌ Dataset not found")
            return False
            
        # Find all image files
        image_extensions = ['.jpg', '.jpeg', '.png', '.bmp']
        image_files = []
        
        for ext in image_extensions:
            image_files.extend(self.dataset_path.rglob(f"*{ext}"))
            image_files.extend(self.dataset_path.rglob(f"*{ext.upper()}"))
        
        print(f"Found {len(image_files)} images")
        
        # Analyze directory structure
        subdirs = [d for d in self.dataset_path.iterdir() if d.is_dir()]
        print(f"Subdirectories: {[d.name for d in subdirs]}")
        
        # Sample a few images to understand content
        if image_files:
            print("\nSample image analysis:")
            sample_images = image_files[:5]
            
            for img_path in sample_images:
                try:
                    img = cv2.imread(str(img_path))
                    if img is not None:
                        h, w = img.shape[:2]
                        print(f"  {img_path.name}: {w}x{h} pixels")
                except Exception as e:
                    print(f"  {img_path.name}: Error loading - {e}")
        
        return len(image_files) > 0
    
    def initialize_detector(self):
        """Initialize our fallback detection system."""
        print("Initializing detection system...")
        self.detector = FallbackDetection(self.config)
        print("✅ Detection system ready")
    
    def test_on_dataset(self, max_images=50):
        """Test our detection system on the dataset."""
        print(f"\n=== TESTING ON DATASET (max {max_images} images) ===")
        
        # Find all image files
        image_extensions = ['.jpg', '.jpeg', '.png', '.bmp']
        image_files = []
        
        for ext in image_extensions:
            image_files.extend(self.dataset_path.rglob(f"*{ext}"))
            image_files.extend(self.dataset_path.rglob(f"*{ext.upper()}"))
        
        if not image_files:
            print("❌ No images found in dataset")
            return
        
        # Limit number of images to test
        test_images = image_files[:max_images]
        print(f"Testing on {len(test_images)} images...")
        
        successful_detections = 0
        total_dice_detected = 0
        total_processing_time = 0
        
        for i, img_path in enumerate(test_images):
            print(f"\nProcessing {i+1}/{len(test_images)}: {img_path.name}")
            
            try:
                # Load image
                image = cv2.imread(str(img_path))
                if image is None:
                    print(f"  ❌ Failed to load image")
                    continue
                
                # Run detection
                start_time = time.time()
                detections = self.detector.detect_dice(image)
                processing_time = (time.time() - start_time) * 1000
                total_processing_time += processing_time
                
                # Analyze results
                dice_count = len(detections)
                total_dice_detected += dice_count
                
                if dice_count > 0:
                    successful_detections += 1
                    print(f"  ✅ Detected {dice_count} dice ({processing_time:.1f}ms)")
                    
                    for j, dice in enumerate(detections):
                        print(f"    Dice {j+1}: Value={dice['value']}, "
                              f"Method={dice['method']}, "
                              f"Confidence={dice['confidence']:.2f}, "
                              f"Area={dice['area']:.0f}")
                else:
                    print(f"  ❌ No dice detected ({processing_time:.1f}ms)")
                
                # Store detailed results
                self.results.append({
                    'image_path': str(img_path),
                    'image_name': img_path.name,
                    'detection_count': dice_count,
                    'detections': detections,
                    'processing_time_ms': processing_time,
                    'image_size': image.shape[:2]
                })
                
            except Exception as e:
                print(f"  ❌ Error processing image: {e}")
        
        # Generate summary
        self.generate_dataset_summary(test_images, successful_detections, 
                                    total_dice_detected, total_processing_time)
    
    def generate_dataset_summary(self, test_images, successful_detections, 
                                total_dice_detected, total_processing_time):
        """Generate comprehensive summary of dataset testing."""
        print("\n" + "=" * 60)
        print("DATASET TESTING SUMMARY")
        print("=" * 60)
        
        total_images = len(test_images)
        detection_rate = (successful_detections / total_images) * 100
        avg_processing_time = total_processing_time / total_images
        avg_dice_per_image = total_dice_detected / total_images
        
        print(f"Images tested: {total_images}")
        print(f"Successful detections: {successful_detections}")
        print(f"Detection rate: {detection_rate:.1f}%")
        print(f"Total dice detected: {total_dice_detected}")
        print(f"Average dice per image: {avg_dice_per_image:.1f}")
        print(f"Average processing time: {avg_processing_time:.1f}ms")
        
        # Method analysis
        method_counts = {}
        value_distribution = {}
        
        for result in self.results:
            for detection in result['detections']:
                method = detection['method']
                value = detection['value']
                
                method_counts[method] = method_counts.get(method, 0) + 1
                value_distribution[value] = value_distribution.get(value, 0) + 1
        
        print(f"\nDetection methods used:")
        for method, count in method_counts.items():
            percentage = (count / total_dice_detected) * 100 if total_dice_detected > 0 else 0
            print(f"  {method}: {count} ({percentage:.1f}%)")
        
        print(f"\nDice value distribution:")
        for value in sorted(value_distribution.keys()):
            count = value_distribution[value]
            percentage = (count / total_dice_detected) * 100 if total_dice_detected > 0 else 0
            print(f"  {value}: {count} ({percentage:.1f}%)")
        
        # Performance insights
        print(f"\nPerformance Insights:")
        
        if detection_rate < 50:
            print("⚠️  LOW DETECTION RATE - May indicate:")
            print("   - Dataset contains challenging angles/lighting")
            print("   - Our algorithm needs angle-agnostic improvements")
            print("   - Original training data bias (top-down only)")
        elif detection_rate > 80:
            print("✅ HIGH DETECTION RATE - Algorithm performs well on this data")
        
        if avg_dice_per_image > 3:
            print("📊 MULTI-DICE IMAGES - Dataset contains multiple dice per image")
            print("   - Good for testing multi-object detection")
        
        # Save detailed results
        self.save_detailed_results()
    
    def save_detailed_results(self):
        """Save detailed test results to JSON file."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        results_file = f"kaggle_dataset_results_{timestamp}.json"
        
        # Convert Path objects to strings for JSON serialization
        json_results = []
        for result in self.results:
            json_result = result.copy()
            json_result['image_path'] = str(result['image_path'])
            json_results.append(json_result)
        
        with open(results_file, 'w') as f:
            json.dump({
                'timestamp': timestamp,
                'dataset_path': str(self.dataset_path),
                'total_images_tested': len(self.results),
                'results': json_results
            }, f, indent=2)
        
        print(f"\nDetailed results saved to: {results_file}")
    
    def create_sample_visualization(self, num_samples=5):
        """Create visualizations of sample detections."""
        print(f"\n=== CREATING SAMPLE VISUALIZATIONS ===")
        
        if not self.results:
            print("No results to visualize")
            return
        
        # Find results with successful detections
        successful_results = [r for r in self.results if r['detection_count'] > 0]
        
        if not successful_results:
            print("No successful detections to visualize")
            return
        
        sample_results = successful_results[:num_samples]
        output_dir = Path("kaggle_visualizations")
        output_dir.mkdir(exist_ok=True)
        
        for i, result in enumerate(sample_results):
            try:
                # Load original image
                image_path = Path(result['image_path'])
                image = cv2.imread(str(image_path))
                
                if image is None:
                    continue
                
                # Draw detections
                for detection in result['detections']:
                    center = tuple(map(int, detection['center']))
                    
                    # Draw circle around detection
                    cv2.circle(image, center, 30, (0, 255, 0), 2)
                    
                    # Draw text with value and method
                    text = f"{detection['value']} ({detection['method'][:4]})"
                    cv2.putText(image, text, (center[0]-20, center[1]-40), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                
                # Save annotated image
                output_path = output_dir / f"sample_{i+1}_{image_path.stem}_annotated.jpg"
                cv2.imwrite(str(output_path), image)
                print(f"  Saved: {output_path.name}")
                
            except Exception as e:
                print(f"  Error creating visualization {i+1}: {e}")
        
        print(f"Visualizations saved to: {output_dir}")


def main():
    """Main testing function."""
    print("🎲 KAGGLE DATASET TESTING TOOL")
    print("Testing our dice detection against nell-byler dataset")
    print("=" * 60)
    
    tester = KaggleDatasetTester()
    
    try:
        # Step 1: Download dataset
        if not tester.download_dataset():
            print("❌ Failed to download dataset")
            print("Please set up Kaggle API credentials first")
            return
        
        # Step 2: Analyze dataset structure
        if not tester.analyze_dataset_structure():
            print("❌ Failed to analyze dataset")
            return
        
        # Step 3: Initialize detection system
        tester.initialize_detector()
        
        # Step 4: Test on dataset
        max_images = int(input("\nHow many images to test (default 30)? ") or "30")
        tester.test_on_dataset(max_images)
        
        # Step 5: Create visualizations
        create_viz = input("\nCreate sample visualizations? (y/n): ").lower().strip()
        if create_viz == 'y':
            tester.create_sample_visualization()
        
        print("\n✅ Testing complete!")
        
    except KeyboardInterrupt:
        print("\n❌ Testing interrupted by user")
    except Exception as e:
        print(f"❌ Testing failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main() 